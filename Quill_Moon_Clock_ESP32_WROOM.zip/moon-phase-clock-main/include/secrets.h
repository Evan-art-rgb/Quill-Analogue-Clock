#ifndef SECRETS_H
#define SECRETS_H

// Local Wi-Fi configuration
const char* WIFI_SSID     = "my WNN mkIi";
const char* WIFI_PASSWORD = "myrolextimepeice";

// New Zealand timezone with automatic NZST / NZDT daylight saving
const char* TIMEZONE = "NZST-12NZDT,M9.5.0,M4.1.0/3";

#endif
